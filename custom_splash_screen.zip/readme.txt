### How to install custom splash screen

### 1. In config.xml change
	<preference name="SplashScreen" value="screen" />
### to
	<preference name="SplashScreen" value="customspinner" />

### 2. Copy all files from archive to:
	platforms/android/res/drawable
### or
	platforms/android/app/src/main/res/drawable